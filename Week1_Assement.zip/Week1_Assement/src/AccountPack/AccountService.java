package AccountPack;

import Exceptions.InvalidAmountException;
import Exceptions.AccountNotFoundException;
import Exceptions.InsufficientFundsException;

import java.util.ArrayList;
import java.util.List;

public class AccountService {
    List<Account> al = new ArrayList<>();

    public boolean isValidAccount(int accNumber) throws AccountNotFoundException {
        for (Account acc : al) {
            if (acc.getAccNumber().equals(accNumber)) {  
                return true;
            }
        }
        throw new AccountNotFoundException("Account not found.");
    }

    public void deposit(int accNumber, float amt) throws InvalidAmountException, AccountNotFoundException {
        if (amt < 0) {
            throw new InvalidAmountException("Amount to deposit must be positive.");
        }

        for (Account account : al) {
            if (account.getAccNumber().equals(accNumber)) {  
                account.setBalance(account.getBalance() + amt);  
                return;
            }
        }

        throw new AccountNotFoundException("Account not found.");
    }
    
    public void withdraw(int accNumber, float amt) throws InvalidAmountException, InsufficientFundsException, AccountNotFoundException {
        if (amt < 500) {
            throw new InvalidAmountException("Minimum withdrawal amount is 500.");
        }

        for (Account account : al) {
            if (account.getAccNumber().equals(accNumber)) {  
                if (account.getType() == Account.AccountType.SAVINGS && account.getBalance() - amt < 1000) {
                    throw new InsufficientFundsException("Insufficient funds for withdrawal.");
                }
                if (account.getType() == Account.AccountType.CURRENT && account.getBalance() - amt < 5000) {
                    throw new InsufficientFundsException("Insufficient funds for withdrawal.");
                }

                account.setBalance(account.getBalance() - amt);  
                return;
            }
        }

        throw new AccountNotFoundException("Account not found.");
    }

    public float getBalance(int accNumber) throws AccountNotFoundException {
        for (Account account : al) {
            if (account.getAccNumber().equals(accNumber)) {  
                return account.getBalance();
            }
        }
        throw new AccountNotFoundException("Account not found.");
    }
}
