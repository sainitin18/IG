package AccountPack;

import java.util.Scanner;
import Exceptions.InvalidAmountException;
import Exceptions.AccountNotFoundException;
import Exceptions.InsufficientFundsException;
import Exceptions.LowBalanceException;

public class AccountTest {
    public static void main(String[] args) throws AccountNotFoundException,InvalidAmountException,InsufficientFundsException,LowBalanceException {
        Scanner scanner = new Scanner(System.in);
        AccountService as = new AccountService();
        Account account1 = new Account(101, "Virat", Account.AccountType.SAVINGS, 2000f);
        Account account2 = new Account(102, "Bumhra", Account.AccountType.CURRENT, 6000f);
        as.al.add(account1);
        as.al.add(account2);
        
        System.out.println("Enter account number to check balance:");
        int accNo = scanner.nextInt();
        System.out.println("Balance: " + as.getBalance(accNo));

        System.out.println("Enter amount to deposit:");
        float depositAmt = scanner.nextFloat();
        as.deposit(accNo, depositAmt);
        System.out.println("New balance after deposit: " + as.getBalance(accNo));

        System.out.println("Enter amount to withdraw:");
        float withdrawAmt = scanner.nextFloat();
        as.withdraw(accNo, withdrawAmt);
        System.out.println("New balance after withdrawal: " + as.getBalance(accNo));
        scanner.close();
    }
}
